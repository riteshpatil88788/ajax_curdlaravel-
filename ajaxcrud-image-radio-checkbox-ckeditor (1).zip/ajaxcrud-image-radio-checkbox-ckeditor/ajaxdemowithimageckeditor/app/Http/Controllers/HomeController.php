<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
use Yajra\Datatables\Datatables;

class HomeController extends Controller
{

    public function index(Request $request)
    {

        if ($request->ajax()) {

            $data = User::all();

            return Datatables::of($data)
                ->addIndexColumn()

                ->addColumn('image', function ($row) {
                    if (empty($row->image)) {
                        $img = '<img src="' . asset('images/demo.png') . '" alt="Image" width="80" height="80">';
                    } else {
                        $img = '<img src="' . asset('images/' . $row->image) . '" alt="Image" width="80" height="80">';
                    }
                    return $img;
                })
                ->addColumn('action', function ($row) {

                    $btn = '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="View" class="me-1 btn btn-info btn-sm showProduct"><i class="fa-regular fa-eye"></i> View</a>';
                    $btn = $btn . '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-primary btn-sm editProduct"><i class="fa-regular fa-pen-to-square"></i> Edit</a>';

                    $btn = $btn . ' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Delete" class="btn btn-danger btn-sm deleteProduct"><i class="fa-solid fa-trash"></i> Delete</a>';

                    return $btn;
                })
                ->rawColumns(['image', 'action'])
                ->make(true);
        }
        return view('user.index');

    }


    public function show($id)
    {
        $user = User::findOrfail($id);
        return response()->json($user);
    }



    public function useredit($id)
    {
        $user = User::findOrfail($id);
        return response()->json($user);
    }


    public function destroy($id)
    {
        User::findOrfail($id)->delete();
        return response()->json(['success' => true]);
    }

    public function userstore(Request $request)
    {

        $request->validate([
            'name' => 'required|string|max:255',
            'gender' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'hobbies' => 'required',
            'hobbies.*' => 'string|max:255',
            'description' => 'required',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($image = $request->file('image')) {
            $imageName = time() . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move('images', $imageName);
        }
        User::create([
            'name' => $request->name,
            'gender' => $request->gender,
            'city' => $request->city,
            'hobbies' => $request->hobbies,
            'description' => $request->description,
            'image' => $imageName,
        ]);

        return response()->json(['success' => true]);
    }


    public function userupdate(Request $request)
    {

        $request->validate([
            'name' => 'required',
            'gender' => 'required',
            'city' => 'required',
            'hobbies' => 'required',
            'description' => 'required'

        ]);



        if ($image = $request->file('image')) {
            $imageName = time() . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move('images', $imageName);

            User::find($request->id)->update([
                'image' => $imageName,
            ]);
        }
        User::find($request->id)->update([
            'name' => $request->name,
            'gender' => $request->gender,
            'city' => $request->city,
            'hobbies' => $request->hobbies,
            'description' => $request->description

        ]);

        return response()->json(['success' => true]);



    }


}
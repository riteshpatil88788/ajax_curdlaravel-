<!DOCTYPE html>
<html>

<head>
    <title>Laravel 11 Ajax CRUD with image</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
</head>

<body>

    <div class="container">
        <div class="card mt-5">

            <div class="card-body">
                <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-3">
                    <a class="btn btn-success btn-sm" href="javascript:void(0)" id="createNewProduct"> <i
                            class="fa fa-plus"></i> Create New User</a>
                </div>

                <table class="table table-bordered data-table">
                    <thead>
                        <tr>
                            <th width="60px">No</th>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>Hobbies</th>
                            <th>City</th>
                            <th>Image</th>
                            <th width="280px">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <div class="modal fade" id="ajaxModel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modelHeading"> Add User</h4>
                </div>
                <div class="modal-body">
                    <form id="productForm" name="productForm" class="form-horizontal" enctype="multipart/form-data">

                        <div class="alert alert-danger print-error-msg" style="display:none">
                            <ul></ul>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Name:</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name"
                                    value="" maxlength="50">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Name:</label>
                            <div class="col-sm-12">
                                <input type="radio" id="gender" name="gender" value="1"> Male
                                <input type="radio" id="gender" name="gender" value="2"> Female
                            </div>
                        </div>


                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Hobbies</label>
                            <div class="col-sm-12">
                                <input type="checkbox" name="hobbies[]" value="1"> Cricket
                                <input type="checkbox" name="hobbies[]" value="2"> Football
                                <input type="checkbox" name="hobbies[]" value="3"> Volleyball
                                <input type="checkbox" name="hobbies[]" value="4"> Ruckby
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">City:</label>
                            <div class="col-sm-12">
                                <select class="form-control" id="city" name="city">
                                    <option value="" id="demo">Select City</option>
                                    <option value="1" class="form-control">Indore</option>
                                    <option value="2" class="form-control">Ujjain</option>
                                    <option value="3" class="form-control">Bhopal</option>
                                    <option value="4" class="form-control">Tikamgrah</option>
                                    <option value="5" class="form-control">Mandsaur</option>
                                    <option value="6" class="form-control">Dhar</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class=" control-label col-form-label">Description</label>
                            <div class="col-sm-12">
                                <textarea class="form-control tinymce description" id="editor1" name="description"
                                    rows="50" cols="100"></textarea>

                            </div>
                        </div>


                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">Image</label>
                            <div class="col-sm-12">
                                <input type="file" id="image" name="image">
                            </div>
                        </div>



                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-success mt-2" id="saveBtn" value="create"><i
                                    class="fa fa-save"></i> Submit
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="showModel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modelHeading"><i class="fa-regular fa-eye"></i> Show User</h4>
                </div>

                <div class="modal-body">
                    <p><strong>Name:</strong> <span class="show-name"></span></p>
                    <p><strong>Gender:</strong>
                        <input type="radio" class="show-gender" name="gender" value="1">Male
                        <input type="radio" class="show-gender" name="gender" value="2"> Female

                    </p>

                    <p><strong>Hobbies:</strong>
                        <input type="checkbox" class="show-hobbies" name="hobbies[]" value="1">Cricket
                        <input type="checkbox" class="show-hobbies" name="hobbies[]" value="2"> Football
                        <input type="checkbox" class="show-hobbies" name="hobbies[]" value="3">Volleyball
                        <input type="checkbox" class="show-hobbies" name="hobbies[]" value="4"> Ruckby

                    </p>


                    <div class="form-group">
                        <label for="name" class="col-sm-2 control-label">City:</label>
                        <div class="col-sm-12">
                            <select class="form-control show-city" name="city">
                                <option value="1" class="form-control">Indore</option>
                                <option value="2" class="form-control">Ujjain</option>
                                <option value="3" class="form-control">Bhopal</option>
                                <option value="4" class="form-control">Tikamgrah</option>
                                <option value="5" class="form-control">Mandsaur</option>
                                <option value="6" class="form-control">Dhar</option>
                            </select>
                        </div>

                    </div>

                    <img id="show-image" src="" alt="RS Diagram" width="50" height="50 mt-2">

                    <div class="form-group row">
                        <label for="description" class=" control-label col-form-label">Description</label>
                        <div class="col-sm-12">
                            <textarea class="form-control tinymce description" id="editor2" name="description"
                                rows="auto" cols="auto"></textarea>

                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>

    <div class=" modal fade" id="editModel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modelHeading"><i class="fa-regular fa-edit"></i> Edit User
                    </h4>
                </div>
                <div class="modal-body">

                    <form id="editForm" name="editForm" class="form-horizontal" enctype="multipart/form-data">

                        <input type="hidden" name="id" id="id">
                        <input type="text" class="form-control editshow-name" id="name" name="name"
                            placeholder="Enter Name" value="">
                        <p><strong>Gender:</strong>
                            <input type="radio" class="editshow-gender" name="gender" value="1"> Male
                            <input type="radio" class="editshow-gender" name="gender" value="2"> Female
                        </p>

                        <p><strong>Hobbies:</strong>
                            <input type="checkbox" class="editshow-hobbies" name="hobbies[]" value="1">Cricket
                            <input type="checkbox" class="editshow-hobbies" name="hobbies[]" value="2">
                            Football
                            <input type="checkbox" class="editshow-hobbies" name="hobbies[]" value="3">Volleyball
                            <input type="checkbox" class="editshow-hobbies" name="hobbies[]" value="4">
                            Ruckby

                        </p>


                        <div class="form-group">
                            <label for="name" class="col-sm-2 control-label">City:</label>
                            <div class="col-sm-12">
                                <select class="form-control  editshow-city" name="city">
                                    <option value="1" class="form-control">Indore</option>
                                    <option value="2" class="form-control">Ujjain</option>
                                    <option value="3" class="form-control">Bhopal</option>
                                    <option value="4" class="form-control">Tikamgrah</option>
                                    <option value="5" class="form-control">Mandsaur</option>
                                    <option value="6" class="form-control">Dhar</option>
                                </select>
                            </div>
                        </div>

                        <img id="editshow-image-1" src="" alt="RS Diagram" width="50" height="50 mt-2">
                        <div class="form-group">
                            <label for="image" class="col-sm-2 control-label">Image</label>
                            <div class="col-sm-12">
                                <input type="file" id="editshow-image" name="image">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class=" control-label col-form-label">Description</label>
                            <div class="col-sm-12">
                                <textarea class="form-control tinymce description" id="editor3" name="description"
                                    rows="auto" cols="auto"></textarea>

                            </div>
                        </div>


                        <div ss="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-success mt-2" id="editBtn" value="create"><i
                                    class="fa fa-save"></i> Submit
                            </button>
                        </div>

                    </form>




                </div>
            </div>
        </div>
    </div>



</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/5.0.0/tinymce.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    tinymce.init({
        selector: 'textarea.tinymce',
        menubar: false,
        plugins: [
            'advlist autolink lists link image charmap print preview anchor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table paste code help wordcount'
        ],
        toolbar: "insertfile undo redo | styleselect | bold italic backcolor | removeformat | help | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image fullpage | forecolor backcolor emoticons | preview | code"
    });
});
</script>
<script type="text/javascript">
$(function() {

    $('#demo').hide();
    /*------------------------------------------
     --------------------------------------------
     Pass Header Token
     --------------------------------------------
     --------------------------------------------*/
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    /*------------------------------------------
    --------------------------------------------
    Render DataTable
    --------------------------------------------
    --------------------------------------------*/
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('home.index') }}",
        columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex'
            },
            {
                data: 'name',
                name: 'name'
            },


            {
                data: 'gender',
                name: 'gender',
                render: function(data) {
                    return (data == 1) ? 'Male' : 'Female';
                }

            },
            {
                data: 'hobbies',
                name: 'hobbies',


                render: function(data) {
                    var hobbies = data.split(',');
                    var hobbieslist = [];
                    if (hobbies.includes('1')) {
                        hobbieslist.push('Cricket');
                    }
                    if (hobbies.includes('2')) {
                        hobbieslist.push('Football');
                    }
                    if (hobbies.includes('3')) {
                        hobbieslist.push('Volleyball');
                    }
                    if (hobbies.includes('4')) {
                        hobbieslist.push('Ruckby');
                    }

                    return (hobbieslist.length > 0) ? hobbieslist.join(',') : '';
                }
            },
            {
                data: 'city',
                name: 'city',
                render: function(data) {
                    if (data == '1') {
                        return 'Indore';
                    }
                    if (data == '2') {
                        return 'Ujjain';
                    }
                    if (data == '3') {
                        return 'Bhopal';
                    }
                    if (data == '4') {
                        return 'Tikamgrah';
                    }
                    if (data == '5') {
                        return 'Mandsaur';
                    }
                    if (data == '6') {
                        return 'Dhar';
                    }

                }
            },


            {
                data: 'image',
                name: 'image'
            },


            {
                data: 'action',
                name: 'action',
                orderable: false,
                searchable: false
            },
        ]
    });



    /***********************************************/
    /***********/
    //Show User
    /***********/
    /***********************************************/



    $('body').on('click', '.showProduct', function() {
        var id = $(this).data('id');
        var url = "{{route('home.show', ':id')}}".replace(':id', id);
        $.get(url, function(data) {
            $('#showModel').modal('show');
            $('.show-name').text(data.name);
            $(".show-city").val(data.city);
            if (data.gender == '1') {
                $(".show-gender[value='1']").prop("checked", true);
            } else if (data.gender == '2') {
                $(".show-gender[value='2']").prop("checked", true);
            }

            var hobbies = data.hobbies;
            $(".show-hobbies").each(function() {
                var checkedValue = $(this).val();
                if (hobbies.includes((checkedValue))) {
                    $(this).prop("checked", true);
                } else {
                    $(this).prop("checked", false);
                }
            });

            if (data.image) {
                $("#show-image").attr('src', 'images/' + data.image);
            } else {
                $("#show-image").attr('src', 'images/demo.png');
            }

            var editor2 = tinymce.get('editor2').setContent(data.description);
            if (editor2) {
                tinymce.get('editor2').setContent(data.description);
            }






        })
    });




    /***********************************************/
    /***********/
    //Delete User
    /***********/
    /***********************************************/






    $('body').on('click', '.deleteProduct', function() {

        var id = $(this).data("id");
        var confirmed = confirm("Are You sure want to delete?");
        if (confirmed) {
            var url = "{{route('home.delete', ':id')}}".replace(':id', id);

            $.ajax({
                type: "DELETE",
                url: url,
                success: function(data) {
                    table.draw();
                },
                error: function(data) {
                    console.log('Error:', data);
                }
            });
        }
    });


    /***********************************************/
    /***********/
    //Store User
    /***********/
    /***********************************************/



    $('#createNewProduct').click(function() {
        $('#saveBtn').val("create-product");
        $('#product_id').val('');
        $('#productForm').trigger("reset");
        $('#ajaxModel').modal('show');
    });




    $('#productForm').submit(function(e) {
        e.preventDefault();

        var formData = new FormData();
        var name = $('#name').val();
        var gender = $('#gender').val();
        var city = $('#city').val();
        var selectedHobbies = [];
        $('input[name="hobbies[]"]:checked').each(function() {
            selectedHobbies.push($(this).val());
        });

        var description = tinymce.get('editor1').getContent();
        var image = $('#image').prop('files')[0];
        formData.append('name', name);
        formData.append('gender', gender);
        formData.append('city', city);
        formData.append('hobbies', selectedHobbies);
        formData.append('image', image);
        formData.append('description', description);
        formData.append('_token', $('meta[name="csrf-token"]').attr('content'));
        $('#saveBtn').html('Sending...').prop('disabled', true);

        $.ajax({
            type: 'POST',
            url: "{{ route('user.store') }}",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                $('#saveBtn').html('Submit').prop('disabled', false);
                $('#productForm').trigger("reset");
                $('#ajaxModel').modal('hide');
                table.draw();
            },
            error: function(response) {
                $('#saveBtn').html('Submit').prop('disabled', false);
                $('#productForm').find(".print-error-msg").find("ul").html('');
                $('#productForm').find(".print-error-msg").css('display', 'block');
                $.each(response.responseJSON.errors, function(key, value) {
                    $('#productForm').find(".print-error-msg").find("ul")
                        .append(
                            '<li>' + value + '</li>');
                });
            }
        });
    });

    /***********************************************/
    /***********/
    //Edit User
    /***********/
    /***********************************************/


    $('body').on('click', '.editProduct', function() {

        var id = $(this).data('id');
        var url = "{{route('user.edit', ':id')}}".replace(':id', id);
        $.get(url, function(data) {
            $('#editModel').modal('show');
            $('.editshow-name').val(data.name);
            $(".editshow-city").val(data.city);




            $('#id').val(data.id);
            if (data.gender == '1') {
                $(".editshow-gender[value='1']").prop("checked", true);
            } else if (data.gender == '2') {
                $(".editshow-gender[value='2']").prop("checked", true);
            }


            var hobbies = data.hobbies;
            $(".editshow-hobbies").each(function() {
                var checkedValue = $(this).val();
                if (hobbies.includes((checkedValue))) {
                    $(this).prop("checked", true);
                } else {
                    $(this).prop("checked", false);
                }
            });

            if (data.image) {
                $("#editshow-image-1").attr('src', 'images/' + data.image);
            } else {
                $("#editshow-image-1").attr('src', 'images/demo.png');
            }

            tinymce.get('editor3').setContent(data.description);
        })
    });






    $('#editForm').submit(function(e) {
        e.preventDefault();

        var formData = new FormData();
        var name = $('.editshow-name').val();
        var id = $('#id').val();
        var gender = $('#gender').val();
        var city = $('.editshow-city').val();
        var selectedHobbies = [];
        $('input[name="hobbies[]"]:checked').each(function() {
            selectedHobbies.push($(this).val());
        });

        var image = $('#editshow-image').prop('files')[0];
        if (image) {
            formData.append('image', image);
        }

        var description = tinymce.get('editor3').getContent();
        formData.append('name', name);
        formData.append('gender', gender);
        formData.append('city', city);
        formData.append('hobbies', selectedHobbies);
        formData.append('image', image);
        formData.append('description', description);
        formData.append('_token', $('meta[name="csrf-token"]').attr('content'));



        $('#editBtn').html('Sending...');

        var url = "{{route('user.update', ':id')}}".replace(':id', id);

        $.ajax({
            type: 'POST',
            url: url,
            data: formData,
            processData: false,
            contentType: false,

            success: (response) => {
                $('#editBtn').html('Submit');
                $('#editForm').trigger("reset");
                $('#editModel').modal('hide');
                table.draw();
            },
            error: function(response) {
                $('#editBtn').html('Submit');
                $('#editForm').find(".print-error-msg").find("ul").html('');
                $('#editForm').find(".print-error-msg").css('display', 'block');
                $.each(response.responseJSON.errors, function(key, value) {
                    $('#editForm').find(".print-error-msg").find("ul").append(
                        '<li>' + value + '</li>');
                });
            }
        });

    });




});
</script>

</html>